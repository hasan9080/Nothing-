## Personal Portfolio

### [Live Site](https://tanveer-e09d4.web.app)

![Portfolio Website](https://firebasestorage.googleapis.com/v0/b/bucket-a2d0b.appspot.com/o/postImages%2Ftanveer-portfolio.png?alt=media&token=ef272d0a-5004-469a-9ecb-38c521d6839f)

This is a code repository for the corresponding video tutorial. Your portfolio is your resume and your business card.

In this video, we will create a full Personal Development Portfolio. We're going to use React and Next.js.

Setup:

- run `npm i && npm run build && npm run dev`


## If you like it give it a star ⭐